package com.ibik.nameservices.nameservices.Students;

import org.springframework.data.repository.CrudRepository;

public interface StudentsRepo extends CrudRepository<Students, Integer> {

}
