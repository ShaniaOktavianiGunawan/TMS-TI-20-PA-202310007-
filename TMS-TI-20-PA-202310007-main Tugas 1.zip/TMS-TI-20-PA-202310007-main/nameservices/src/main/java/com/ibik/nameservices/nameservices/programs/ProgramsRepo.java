package com.ibik.nameservices.nameservices.programs;

import org.springframework.data.repository.CrudRepository;

public interface ProgramsRepo extends CrudRepository<Programs, Integer> {

}
