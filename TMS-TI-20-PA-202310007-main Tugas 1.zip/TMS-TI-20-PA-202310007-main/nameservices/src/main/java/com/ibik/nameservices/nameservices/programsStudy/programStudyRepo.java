package com.ibik.nameservices.nameservices.programsStudy;

import org.springframework.data.repository.CrudRepository;

public interface programStudyRepo extends CrudRepository<programStudy, Integer> {

}
