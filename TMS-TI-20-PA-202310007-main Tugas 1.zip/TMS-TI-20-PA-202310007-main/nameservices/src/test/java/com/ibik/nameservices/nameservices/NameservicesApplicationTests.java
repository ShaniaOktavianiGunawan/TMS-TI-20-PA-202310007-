package com.ibik.nameservices.nameservices;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AcademicServicesApplicationTests {

	@Test
	void contextLoads() {
	}

}